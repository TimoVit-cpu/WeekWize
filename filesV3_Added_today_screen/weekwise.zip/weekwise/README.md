# Weekwise

A free school planner (timetable Sun-Thu, assignments, tests with study checklists). Plain HTML, CSS and JavaScript. No frameworks, no server, no accounts.

Files: `index.html` (page), `style.css` (looks), `app.js` (all logic, commented), `manifest.json` + `sw.js` + icons (installable/offline).

## 1. Open it on a computer
Double-click `index.html`. The planner works. Installing and offline mode need https (see below). For a local test with those features, run `python3 -m http.server 8000` in this folder and open http://localhost:8000.

## 2. Host it for free
**Netlify (easiest):** go to app.netlify.com/drop, sign in, and drag the whole `weekwise` folder onto the page. You get an https link.
**GitHub Pages:** create a repository, upload all files, then Settings > Pages > Deploy from branch `main`, folder `/ (root)`. Your link will be `https://YOURNAME.github.io/REPO/`.

## 3. Install on Android
1. Open the https link in Chrome on your phone.
2. Wait a few seconds, then tap the menu (three dots) > **Install app** (or **Add to Home screen**).
3. Open Weekwise from your home screen. Settings also shows an Install button when Chrome offers one.

## 4. Update the app
Edit the files, change the version in `sw.js` (`weekwise-v1` to `weekwise-v2`), and upload again (Netlify: drop the folder again; GitHub: commit). Open the app twice online to get the new version. Your data stays.

## Backup
Settings > Export JSON saves a file; Import restores it (after a confirmation). Use this to move data between phone and computer.

## Known limitations
- Data is stored per browser and device. Phone and computer do **not** sync. Clearing site data erases it, so export now and then.
- Notifications are reliable only while the app is open. On Android Chrome, an installed app may also get an occasional background check (a few times a day at most, timing chosen by the browser, not guaranteed, and it needs the notification permission). Exact-time alerts for a closed app need a paid push server, so none is used.
- Installing and offline mode do not work from `file://`; use https or localhost.
- iPhone support for notifications is limited.
